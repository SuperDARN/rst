/* errstr.h
   ========
   Author: R.J.Barnes
*/

/*
 $License$
*/


char *errstr[]={
"dmaptoncdf - Converts a DataMap file to a Network Common Data Format (netCDF) file.\n",
"dmaptoncdf --help\n",
"dmaptoncdf [-vb] datamap map netcdf\n",

NULL};
